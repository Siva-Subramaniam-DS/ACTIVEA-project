"""Tests package for ACTIVEA.
"""
